﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Управление общими сведениями о сборке осуществляется с помощью 
' набора атрибутов. Измените значения этих атрибутов для изменения сведений,
' общие сведения об этой сборке.

' Review the values of the assembly attributes
<Assembly: AssemblyTitle("Test.VB.AspMvc")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Aleksey Nemiro")> 
<Assembly: AssemblyProduct("Test.VB.AspMvc")> 
<Assembly: AssemblyCopyright("Copyright © Aleksey Nemiro, 2014")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

' Следующий GUID служит для ID-идентификации библиотеки типов, если этот проект видим для COM
<Assembly: Guid("f47d3a09-45f3-4454-86e6-a2f2fb2330b5")> 

' Сведения о версии сборки состоят из указанных ниже четырех значений:
'
'      Основной номер версии
'      Дополнительный номер версии 
'      Номер сборки
'      Редакция
'
' You can specify all the values or you can default the Build and Revision Numbers 
' используя "*", как показано ниже:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
