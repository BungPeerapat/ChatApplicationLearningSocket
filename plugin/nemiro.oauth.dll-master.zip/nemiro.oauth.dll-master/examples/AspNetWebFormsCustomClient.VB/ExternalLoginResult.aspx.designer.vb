﻿'------------------------------------------------------------------------------
' <автоматически создаваемое>
'     Этот код создан программой.
'
'     Изменения в этом файле могут привести к неправильной работе и будут потеряны в случае
'     повторной генерации кода. 
' </автоматически создаваемое>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class ExternalLoginResult

  '''<summary>
  '''Head1 элемент управления.
  '''</summary>
  '''<remarks>
  '''Автоматически создаваемое поле.
  '''Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
  '''</remarks>
  Protected WithEvents Head1 As Global.System.Web.UI.HtmlControls.HtmlHead

  '''<summary>
  '''form1 элемент управления.
  '''</summary>
  '''<remarks>
  '''Автоматически создаваемое поле.
  '''Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
  '''</remarks>
  Protected WithEvents form1 As Global.System.Web.UI.HtmlControls.HtmlForm

  '''<summary>
  '''preResult элемент управления.
  '''</summary>
  '''<remarks>
  '''Автоматически создаваемое поле.
  '''Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
  '''</remarks>
  Protected WithEvents preResult As Global.System.Web.UI.HtmlControls.HtmlGenericControl

  '''<summary>
  '''hlTryAgain элемент управления.
  '''</summary>
  '''<remarks>
  '''Автоматически создаваемое поле.
  '''Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
  '''</remarks>
  Protected WithEvents hlTryAgain As Global.System.Web.UI.WebControls.HyperLink
End Class
