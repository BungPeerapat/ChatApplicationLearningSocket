﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Управление общими сведениями о сборке осуществляется с помощью 
' набора атрибутов. Измените значения этих атрибутов для изменения сведений,
' общие сведения об этой сборке.

' Review the values of the assembly attributes
<Assembly: AssemblyTitle("AspNetWebFormsCustomClient.VB")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("AspNetWebFormsCustomClient.VB")> 
<Assembly: AssemblyCopyright("Copyright © Aleksey Nemiro, 2015")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'Следующий GUID служит для идентификации библиотеки типов, если этот проект видим для COM
<Assembly: Guid("33799663-c2da-4b38-a8cc-0a12b121c10b")> 

' Сведения о версии сборки состоят из указанных ниже четырех значений:
'
'      Основной номер версии
'      Дополнительный номер версии 
'      Номер сборки
'      Редакция
'
' You can specify all the values or you can default the Build and Revision Numbers 
' используя "*", как показано ниже:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
